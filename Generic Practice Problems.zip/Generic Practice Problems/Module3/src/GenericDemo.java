class Gen<T>{
	T Ob; //define data member of type T
	
	Gen(T obj){
		Ob=obj;// define constructor 
	}
	
	T getGen()
	{
		return Ob;
	}
	
	void showGen(){
		System.out.println("Type of T is "+ Ob.getClass().getName());
	}
}



public class GenericDemo {

	public static void main(String[] args) {
		Gen<Integer> iob;
		iob = new Gen<Integer> (88);
		iob.showGen();
		System.out.println(iob.getGen());
		
		Gen<Double> iob1;
		iob1 = new Gen<Double> (88.0);
		iob1.showGen();
		System.out.println(iob1.getGen());
		
		
		Gen<String> iob3;
		iob3 = new Gen<String> ("Hello");
		iob3.showGen();
		System.out.println(iob3.getGen());
		// TODO Auto-generated method stub

	}

}
