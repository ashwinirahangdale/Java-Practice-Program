class Glass<T>{
	
}
class Tray{
	//public void add(Glass<T> G) {
	public void add(Glass <?> G) {
		System.out.println("This is unbounded wild cards"+G);
	}
}

public class UnboundedWildcardsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Tray t = new Tray();
		t.add(new Glass<String>());

	}

}
