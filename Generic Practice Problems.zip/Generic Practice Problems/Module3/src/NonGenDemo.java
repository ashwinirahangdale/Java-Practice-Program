class NonGen{
	Object Ob;
	NonGen(Object Ob){
		this.Ob=Ob;
	}
	Object get() {
		return Ob;
	}
	void set(Object Ob) {
		this.Ob=Ob;
	}
	void show() {
		System.out.println(Ob.getClass().getName());
	}
	
}


public class NonGenDemo {

	public static void main(String[] args) {
		NonGen Nob;
		Nob = new NonGen(88);
		//int a =  Nob.get();
		float a = (Float) Nob.get(); // Casting is needed
		System.out.println(a);
		Nob.show();
		NonGen Nob1 = new NonGen("Hello WOrld");
		Nob1.show();
		 Nob= Nob1;
		 a=(Integer) Nob.get();
		 Nob=Nob1;
		 Nob1=Nob;
		 //int b= Nob.get();
		

	}

}
