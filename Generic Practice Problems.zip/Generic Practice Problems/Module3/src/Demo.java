class E{
	String str;
	E(String str){
		this.str=str;
	}
}
class Item<E extends Comparable<E>> implements Comparable<E> {

 private int s;
  E t;
 Item(int s, E t1){
	 this.s=s;
	 this.t =t1;
 }

 public E getE() {
     return t;
 }

 @Override
 public int compareTo(E e) {
     return getE().compareTo(e);
 }

 public int compareTo(Item<E> other)
    {
        return getE().compareTo(other.getE());
    }

 }
public class Demo {

	public static void main(String[] args) {
		
		E e = new E("Hello World");
		int s = 10;
		//Item<new E("Hello World")> i = new Item<new E("Hello World")>(s, e);
		

	}

}
