class Test<T> {
T ob; 
Test(T o) {
ob = o;
}
T getob() {
return ob;
}
// Show type of T.
void showType() {
System.out.println("Type of T is " +
ob.getClass().getName());
}
}
class GenDemo {
public static void main(String args[]) {

Test<Integer> iOb;

iOb = new Test<Integer>(88);

iOb.showType();
int v = iOb.getob();
System.out.println("value: " + v);
System.out.println();
Test<String> strOb = new Test<String>("Generics Test");
strOb.showType();
String str = strOb.getob();
System.out.println("value: " + str);
//strOb= iOb;
}
}