class ArrayDemo1<T>{
	T t[];
	ArrayDemo1(T b[]){
		t=b;
	}
	void Display() {
		for(int i=t.length-1;i>=0;i--) {
			System.out.println(t[i]);
		}
	}
}
class Average<T extends Number>{
	T t[];
	Average(T b[]){
		t=b;
	}
	void Cal_Avg(T b[]){
		t=b;
		double sum=0;
		for(int i=0;i<t.length;i++) {
			sum=sum+t[i].doubleValue();
		}
		System.out.println(sum/t.length);
		
		
	}
}

public class Tut1 {

	public static void main(String[] args) {
		Integer nums[] = {1,2,3,4,5,6,7,8,9,11,12,13,14};
		String str[]= {"AB","BC","CD","EF","GH"};
		ArrayDemo1<Integer> Obj = new ArrayDemo1<Integer>(nums);
		
		ArrayDemo1<String> Obj1 = new ArrayDemo1<String>(str);
		Obj.Display();
		Obj1.Display();
		Average<Integer> avg = new Average<Integer>(nums);
		avg.Cal_Avg(nums);

	}

}
