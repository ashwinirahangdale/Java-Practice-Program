
import java.util.ArrayList;;
class Container<T extends Number>
{
	T ob;
	
	
	void set(T ob) {
		this.ob=ob;
	}
	
	T get() {
		return ob;
	}
	void show()
	{
		System.out.println("The type of T is "+ ob.getClass().getName());
	}
	void demo(ArrayList<Integer> Obj) {
		System.out.println();
	}
	
}


public class GenDemo1 {

	public static void main(String[] args) {
		
		Container<Integer> ob =new Container<>();
		ob.show();
		ob.demo(new ArrayList<Integer>());

	}

}
