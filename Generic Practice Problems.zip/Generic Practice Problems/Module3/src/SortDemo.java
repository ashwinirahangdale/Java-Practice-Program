class Sort<T extends Number>{
	private T[] d;
	Sort(T[] o){
		d=o;
	}
	public void Sortmethod(T[] o){
		for(int i=0;i<o.length;i++) {
			for(int j=0;j<(o.length-i-1);j++) {
				if(o[i].doubleValue()>o[i+1].doubleValue()
						) {
					 T v = o[i];
					 o[i]=o[i+1];
					 o[i+1] = v;
					
				}
			}
		
		 
		}
		
	}
}

public class SortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
