class Stats<T extends Number>{
	T[] num;
	Stats(T[] o){
		num=o;
	}
	double avarage()
	{
		double sum =0.0;
		for(int i=0;i<num.length;i++)
			sum=sum+num[i].doubleValue();
		return sum/num.length;
	}
}




public class DemoSuperGen {

	public static void main(String[] args) {
		
		Integer nums [] = {1,2,3,4,5,6,7,10,20,19,23,28};
		Stats<Integer> iob = new Stats<Integer>(nums); // calling parameterized constructor
		double v = iob.avarage();
		System.out.println(v);
		// TODO Auto-generated method stub

	}

}
