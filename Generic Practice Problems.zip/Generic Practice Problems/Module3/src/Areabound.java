class Area <T extends Number>{
    T ob1;
    T ob2;
    T ob3;
   Area(T g,T h,T i)
   {
       this.ob1=g;
        this.ob2=h;
        this.ob3=i;
    }
    double volume(){
   double a =ob1.doubleValue()*ob2.doubleValue();
   return a;
    }
   double volume1(){
   double b =ob1.doubleValue()*ob2.doubleValue()*ob3.doubleValue();
   return b;
}
}
   public class Areabound{
    public static void main(String[]args){
        Area<Integer> iob=new Area<Integer>(10,10,10);
        double v=iob.volume();
        System.out.println("Area of rectangle is "+v);
        double w=iob.volume1();
        System.out.println("Volume of rectangke is "+w);
    }
   }