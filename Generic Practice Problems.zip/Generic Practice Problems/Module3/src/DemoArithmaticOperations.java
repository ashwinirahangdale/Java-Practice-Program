class GenericsArithmetic<T extends Number> {
    private T number1, number2;
    double sum=0,product=1,difference=0;
    public void AddNumbers(T number1, T number2){
        this.number1 = number1;
        this.number2 = number2;  
        sum= number1.doubleValue()+number2.doubleValue();
    }
    public double getSum(){
     // sum.doubleValue() = number1.doubleValue() + number2.doubleValue();
//      when I uncomment the above line I am getting this error message.The operator + is undefined for the argument type(s) T, T
        return sum;
    }
    public void MultNumbers (T number1, T number2){
        this.number1 = number1;
        this.number2 = number2;
      product = number1.doubleValue() * number2.doubleValue();
    }
    public double getProd (){
        return product;
    }
    public void subtractNumbers (T number1, T number2){
        this.number1 = number1;
        this.number2 = number2;
        difference=number1.doubleValue()-number2.doubleValue();
        
    }
    public double getDifference(){
        return difference;
    }
}
class DemoArithmaticOperations {
    public static void main(String[] args) {
        GenericsArithmetic<Integer> integerNumbers = new GenericsArithmetic<>();
        integerNumbers.AddNumbers(100, 100);
        System.out.println("The addition of two numbers is: "+integerNumbers.getSum());
    }
}

