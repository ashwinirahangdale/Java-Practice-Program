import java.util.Scanner;
class Person<T,U>{
	T t;
	U u;
	 Person(T a, U b){
	     t=a;
		 u=b;
		
	}
	public <T, U> void Details(T t, U u) {
		System.out.println("Hello"+ t +"," +"Your age is "+ u);
	}
}
public class Tut2 {

	public static void main(String[] args) {
		String name;
		Integer age;
		Person p[] = new Person[10];
		for(int i=0; i<p.length;i++) {
			//Person p[] = new Person();
			name=null;
			age=0;
			p[i].Details(name, age);
		}
		
		Scanner sc = new Scanner(System.in);
		for(int j=0; j<p.length;j++) {
			//Person p[] = new Person();
			name=sc.nextLine();
			age=sc.nextInt();
			p[j].Details(name, age);
			
		}
			
	}

}
