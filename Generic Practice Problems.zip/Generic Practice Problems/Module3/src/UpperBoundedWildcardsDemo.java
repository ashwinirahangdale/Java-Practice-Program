class GlassOfJuice<T>{
	
}
interface Liquid{

}
class Juice implements Liquid{
	
}
class OrangeJuice extends Juice{}

class Tray1{
	//public void add(GlassOfJuice<? extends OrangeJuice> GoJ) {
	//public void add(GlassOfJuice<? extends Juice> GoJ) {
	public void add(GlassOfJuice<? extends Liquid> GoJ) {
		System.out.println("Upper Bounded Wildcard: "+ GoJ);
	}
}

public class UpperBoundedWildcardsDemo {

	public static void main(String[] args) {
		Tray1 t = new Tray1();
		t.add(new GlassOfJuice<Juice>());
		t.add(new GlassOfJuice<OrangeJuice>());
		t.add(new GlassOfJuice<Liquid>());
		// TODO Auto-generated method stub

	}

}
