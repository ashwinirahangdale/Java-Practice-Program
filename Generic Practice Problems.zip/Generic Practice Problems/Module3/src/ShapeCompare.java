//import java.util.*;
//import java.lang.*;
interface Shape<T extends Number>{
	double getVolume();
	double getArea();
}

class Sphere<T extends Number> implements Shape<T>{
	T radius;
	Sphere(T r){
		this.radius=r;
	}
	 public double getVolume() {
		 //double r=radius.doubleValue();
		 double volume = 4.00*3.14*radius.doubleValue()*radius.doubleValue()*radius.doubleValue();
		 //System.out.println(volume);
		 return volume;
	 }
	 
	 public double getArea() {
		 //double r=radius.doubleValue();
		 double area = 2.00*3.14*radius.doubleValue()*radius.doubleValue();
		 return area;
	 }
	 
}

class Cylinder<T extends Number> implements Shape<T>{
	T radius;
	T height;
	Cylinder(T r,T h){
		this.radius=r;
		this.height=h;
		
	}
	 public double getVolume() {
		 //double r=radius.doubleValue();
		 double volume = 3.14*radius.doubleValue()*radius.doubleValue()*height.doubleValue();
		 //System.out.println(volume);
		 return volume;
	 }
	 
	 public double getArea() {
		 //double r=radius.doubleValue();
		 double area = 2.00*3.14*radius.doubleValue()*height.doubleValue()+3.14*radius.doubleValue()*radius.doubleValue();
		 return area;
	 }
	 
}

public class ShapeCompare<T extends Comparable<T>>{
	Sphere<? extends Number> sp1;
	Cylinder<? extends Number> cy1;
	ShapeCompare(Sphere<? extends Number> sp1,Cylinder<? extends Number> cy1){
		this.sp1=sp1;
		this.cy1=cy1;
	}
	
	public int toComapre() {
		if(sp1.getVolume()>cy1.getVolume())
		return 1;
		else if (sp1.getVolume()<cy1.getVolume())
			return -1;
		return 0;
		
	}
	
	public static void main(String[] args) {
		Sphere<Double> sp1 = new Sphere<Double>(4.00);
		Cylinder<Double> cy1 = new Cylinder<Double>(6.00,12.00);
		ShapeCompare<Double> sp= new ShapeCompare<Double>(sp1, cy1);
		if(sp.toComapre()==1)
			System.out.println("Sphere has greater volume");
		else if(sp.toComapre()==-1)
			System.out.println("Cylinder has greater volume");
		else
			System.out.println("Both are equal in volume");
			
		
		

	}

}
