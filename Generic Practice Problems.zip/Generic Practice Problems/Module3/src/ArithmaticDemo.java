class Operation<T extends Number>{
	T t1, t2;
	Operation(T x, T y){
		t1=x;
		t2=y;
	}
	double add() {
		
		double sum=0;
		sum=t1.doubleValue()+t2.doubleValue();
		return sum;
	}
	
}

public class ArithmaticDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Operation<Double> ob = new Operation<Double>(100.00,123.09);
		double v= ob.add();
		System.out.print(v);
		
	}

}
