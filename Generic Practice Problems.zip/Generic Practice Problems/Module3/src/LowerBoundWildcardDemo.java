class Glass2<T>{}
class Juice1{}
 class Coke{}
 class CokeDiet extends Coke{}
 class Cokezero extends CokeDiet{}
 class Tray2{
	 public void add(Glass2<? extends Cokezero> Goz) {
		 System.out.println("This is Upper Bound Wildcard"+Goz);
	 }
	 public void remove(Glass2<? super CokeDiet> Goz1) {
		 System.out.println("This is Lower Bound Wildcard"+Goz1);

	 }
 }

public class LowerBoundWildcardDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tray2 t2 = new Tray2();
		t2.add(new Glass2<Cokezero>());
		//t2.remove(new Glass2<Cokezero>());
		Glass2<CokeDiet> Goz2 = new Glass2<CokeDiet>();
		t2.remove(Goz2);

	}

}
