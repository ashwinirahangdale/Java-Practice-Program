import java.util.*;
import java.time.LocalDate;
class AB implements Comparable<AB>{
	private Long id;
    public String name;
    private LocalDate dob;
    public int compareTo(AB o)
    {
        return 1;
    }
}
public class Test21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
